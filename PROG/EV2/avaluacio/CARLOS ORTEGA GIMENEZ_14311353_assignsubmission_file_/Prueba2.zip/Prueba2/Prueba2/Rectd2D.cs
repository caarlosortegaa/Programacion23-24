﻿namespace Prueba2
{
    public class Rectd2D 
    {
        public double x;
        public double y;
        public double width;
        public double heigth;
        public Rectd2D(double ix, double iy, double dx, double dy)
        {
            this.x = ix;
            this.y = iy;
            this.width = dx;
            this.heigth = dy;
        }
    }
}
