﻿namespace Prueba2
{
    public class color
    {
        public double r = 0;
        public double g = 0;
        public double b = 0;
        public double a = 0;

        public color(double r, double g , double b , double a)
        {
            this.r = r;
            this.g = g;
            this.b = b;
            this.a = a;
        }
        public color()
        {

        }
    }
}
