﻿namespace Prueba2
{
    public class Program
    { 
       
        static void Main(string[] args)
        {
            
        }
    }
}